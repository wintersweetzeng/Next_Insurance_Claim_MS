DOCKERFILE=docker-compose.yml
docker-compose -f $DOCKERFILE down
